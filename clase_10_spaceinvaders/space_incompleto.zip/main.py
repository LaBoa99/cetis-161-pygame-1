from typing import Any
import pygame
import random
import os
import utils as UTILS

# Configuración
scrip_dir = os.path.dirname(__file__)
pygame.init()
fps = 60
clock = pygame.time.Clock()

ancho, altura = (480, 320)
pantalla = pygame.display.set_mode((ancho, altura))
SPRITESHEET = pygame.image.load(os.path.join(scrip_dir, "space_sprites.png")).convert_alpha()
FRAME_W = 11
FRAME_H = 8
SCALE_FACTOR = 4
# delta time
current_time = pygame.time.get_ticks()
previous_time = current_time

# CLASES
class Bala(pygame.sprite.Sprite):
    def __init__(self, x, y, *groups) -> None:
        super().__init__(*groups)
    
    def update(self, dt) -> None:
        pass
        

class Jugador(pygame.sprite.Sprite):
    def __init__(self, *groups) -> None:
        super().__init__(*groups)
        
    def disparar(self):
        pass
        
    def input(self):
        pass
        
    def update(self, dt):
        pass

    def draw(self, screen):
        pass

#GROUPS
jugador = Jugador()
jugador_balas = pygame.sprite.Group()
while True:
    pantalla.fill((0, 0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            os._exit(0)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_j:
                jugador.disparar()
    # update
    deltatime = (current_time - previous_time) / 1000.0  # Tiempo en segundos
    previous_time = deltatime
    
    jugador.update(deltatime)
    jugador_balas.update(deltatime)
    # Draw
    jugador_balas.draw(pantalla)
    jugador.draw(pantalla)
    # Final
    pygame.display.flip()
    clock.tick(fps)
