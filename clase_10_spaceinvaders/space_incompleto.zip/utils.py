import pygame

def loadFrames(sprite, w, h, row, col, offset_x = 0, offset_y = 0):
    frames = []
    for i in range(col):
        frame = pygame.Surface((w, h), pygame.SRCALPHA)
        frame.blit(sprite, (0, 0), (offset_x + (i * w), offset_y + (row * h),  w, h))
        frames.append(frame)
    return frames 

def scale_image(surface, n = 2):
    return pygame.transform.scale(surface, (surface.get_width() * n, surface.get_height() * n))